import React, { useState } from "react";
import { motion } from "framer-motion";
import Confetti from "react-confetti";

export default function Home() {
  const [name, setName] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (name.trim()) {
      setSubmitted(true);
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 5000);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-pink-200 text-center p-4">
      {showConfetti && <Confetti />}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="bg-white p-6 rounded-2xl shadow-xl max-w-lg w-full"
      >
        <img
          src="https://friendship-day-site-demo.vercel.app/friends.gif"
          alt="friends"
          className="rounded-xl mb-4 w-full"
        />

        <h1 className="text-2xl font-bold text-pink-600 mb-2">
          Happy Friendship Day Bujji!
        </h1>
        <p className="mb-4 text-gray-700">
          From <span className="font-semibold">Chinnu</span> with lots of love 💖
        </p>

        {!submitted ? (
          <form onSubmit={handleSubmit} className="space-y-3">
            <input
              type="text"
              placeholder="Enter your name"
              className="w-full p-2 border border-pink-300 rounded-xl"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <button
              type="submit"
              className="w-full bg-pink-500 text-white py-2 rounded-xl hover:bg-pink-600"
            >
              Open Greeting
            </button>
          </form>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-lg text-gray-800"
          >
            Dear <span className="font-bold text-pink-600">{name}</span>,<br />
            Wishing you a day full of happiness and friendship 🌟
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
